<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tugas 2</title>
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
</head>
<body>
<section class="container">
		<div class="alert alert-primary">
			<h2 class="text-center">Tugas 2</h2>
		</div>
		<div class="row">
		<div class="col-6">
                <div class="card">
                    <div class="card-right">
                        <div class="card-body">
                        <table class="table table-bordered">
					  <thead>
					    <tr>
					      <th scope="col">Nim</th>
					      <th scope="col">Nama</th>
					      <th scope="col">Alamat</th>
					    </tr>
                        <td>1910040002</td>
                        <td>I Gede Putu Saputra</td>
                        <td>Jln. Sultan Salahudin Batu Dawa</td>
					  </thead>
					  <tbody>
					    <tr>

					    </tr>
					  </tbody>
					</table>

            </div>
        </div>
    </div>
</div>
<div class="col-md-2">
		      <div class="card">
	  			<img src="<?= BASE_URL('img/Haha.jpeg'); ?>" alt="">
			</div>
		    </div>
</div>
		
	</section>
</body>
</html>