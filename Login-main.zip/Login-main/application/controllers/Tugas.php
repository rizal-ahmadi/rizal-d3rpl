<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Tugas extends CI_Controller {

    public function kedua()
	{
		$this->load->view('Admin/Tugas_2');
	}

}
